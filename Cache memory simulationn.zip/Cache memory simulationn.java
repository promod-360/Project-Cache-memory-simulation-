import java.util.*;

public class Main {


    static class CacheBlock {
        int tag;
        boolean valid;
        boolean dirty; 
        int lruCounter; 

        CacheBlock() {
            this.valid = false;
            this.dirty = false;
            this.lruCounter = 0;
        }
    }

  
    static final int LRU = 0;
    static final int FIFO = 1;
    static final int WRITE_THROUGH = 0;
    static final int WRITE_BACK = 1;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

      
        try {
            System.out.println("Enter the cache size (in blocks): ");
            int cacheSize = scanner.nextInt();

            System.out.println("Enter the block size (in words): ");
            int blockSize = scanner.nextInt();

            System.out.println("Enter the associativity (1 for direct-mapped, N for N-way): ");
            int associativity = scanner.nextInt();

            System.out.println("Enter the replacement policy (0 for LRU, 1 for FIFO): ");
            int replacementPolicy = scanner.nextInt();

            System.out.println("Enter the write policy (0 for Write-Through, 1 for Write-Back): ");
            int writePolicy = scanner.nextInt();

           
            List<Integer> addresses = Arrays.asList(4, 8, 16, 4, 20, 8, 24, 32, 4, 20);

           
            int numSets = cacheSize / (blockSize * associativity);
            CacheBlock[][] cache = new CacheBlock[numSets][associativity];
            int[] fifoPointer = new int[numSets]; 
            Arrays.fill(fifoPointer, 0); 

          
            for (int i = 0; i < numSets; i++) {
                for (int j = 0; j < associativity; j++) {
                    cache[i][j] = new CacheBlock();
                }
            }

            int cacheHits = 0;
            int cacheMisses = 0;

            
            for (int address : addresses) {
                int blockIndex = (address / blockSize) % numSets;
                int tag = address / (blockSize * numSets);

                boolean hit = false;
                int lruIndex = -1;
                int maxLru = Integer.MIN_VALUE;

               
                for (int i = 0; i < associativity; i++) {
                    if (cache[blockIndex][i].valid && cache[blockIndex][i].tag == tag) {
                        hit = true;
                        cacheHits++;

                      
                        cache[blockIndex][i].lruCounter = 0;
                        for (int j = 0; j < associativity; j++) {
                            if (j != i && cache[blockIndex][j].valid) {
                                cache[blockIndex][j].lruCounter++;
                            }
                        }
                        System.out.println("Cache hit for address " + address);
                        break;
                    }
                }

                if (!hit) {
                  
                    cacheMisses++;
                    System.out.println("Cache miss for address " + address);

                  
                    int replaceIndex = -1;
                    if (replacementPolicy == LRU) { // LRU
                        for (int i = 0; i < associativity; i++) {
                            if (!cache[blockIndex][i].valid) {
                                replaceIndex = i; 
                                break;
                            }
                            if (cache[blockIndex][i].lruCounter > maxLru) {
                                maxLru = cache[blockIndex][i].lruCounter;
                                lruIndex = i;
                            }
                        }
                        if (replaceIndex == -1) {
                            replaceIndex = lruIndex;
                        }
                    } else { 
                        replaceIndex = fifoPointer[blockIndex];
                        fifoPointer[blockIndex] = (fifoPointer[blockIndex] + 1) % associativity;
                    }

                    
                    if (writePolicy == WRITE_BACK && cache[blockIndex][replaceIndex].valid && cache[blockIndex][replaceIndex].dirty) {
                       
                        System.out.println("Writing back dirty block to memory (Tag: " + cache[blockIndex][replaceIndex].tag + ")");
                    }

                   
                    cache[blockIndex][replaceIndex].valid = true;
                    cache[blockIndex][replaceIndex].tag = tag;
                    cache[blockIndex][replaceIndex].dirty = (writePolicy == WRITE_BACK);
                    cache[blockIndex][replaceIndex].lruCounter = 0;

                   
                    for (int i = 0; i < associativity; i++) {
                        if (i != replaceIndex && cache[blockIndex][i].valid) {
                            cache[blockIndex][i].lruCounter++;
                        }
                    }
                }
            }

           
            System.out.println("\nSimulation Results:");
            System.out.println("Total Cache Hits: " + cacheHits);
            System.out.println("Total Cache Misses: " + cacheMisses);
            System.out.printf("Hit Rate: %.2f%%\n", ((double) cacheHits / addresses.size()) * 100);
            System.out.printf("Miss Rate: %.2f%%\n", ((double) cacheMisses / addresses.size()) * 100);

        } catch (InputMismatchException e) {
            System.err.println("Invalid input: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}



